from flask import Flask, render_template

app = Flask(__name__)

@app.route('/',methods = ['GET']) #this is like how you see : www.google.com

def home():
    return render_template("index.html")


if __name__ == '__main__': #this helps you run the app
    app.run(port = 7000, debug = True)
    #when you declare debug = True when you make changes you don't have to keep terminating the server.
