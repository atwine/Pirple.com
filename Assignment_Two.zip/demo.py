from flask import Flask, render_template, redirect, url_for, request

app = Flask(__name__)

#in the route below: "/" means the home pages
@app.route('/',methods = ['GET']) #this is like how you see : www.google.com

def home():
    return render_template("index.html")

#create another route
#seems like routes are the same as pages
@app.route('/football', methods = ['GET'])
def football():
    return   render_template('football.html')

@app.route('/about',methods = ['GET'])
def about():
    return render_template('about.html')


if __name__ == '__main__': #this helps you run the app
    app.run(port = 7000, debug = True)
    #when you declare debug = True when you make changes you don't have to keep terminating the server.
